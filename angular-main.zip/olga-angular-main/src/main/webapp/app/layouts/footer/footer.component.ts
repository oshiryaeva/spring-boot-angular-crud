import { Component } from '@angular/core';

@Component({
  selector: 'olga-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.scss'],
})
export class FooterComponent {}
