jest.mock('@ng-bootstrap/ng-bootstrap');

import { ComponentFixture, TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { OrderItemService } from '../service/order-item.service';

import { OrderItemDeleteDialogComponent } from './order-item-delete-dialog.component';

describe('Component Tests', () => {
  describe('OrderItem Management Delete Component', () => {
    let comp: OrderItemDeleteDialogComponent;
    let fixture: ComponentFixture<OrderItemDeleteDialogComponent>;
    let service: OrderItemService;
    let mockActiveModal: NgbActiveModal;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
        declarations: [OrderItemDeleteDialogComponent],
        providers: [NgbActiveModal],
      })
        .overrideTemplate(OrderItemDeleteDialogComponent, '')
        .compileComponents();
      fixture = TestBed.createComponent(OrderItemDeleteDialogComponent);
      comp = fixture.componentInstance;
      service = TestBed.inject(OrderItemService);
      mockActiveModal = TestBed.inject(NgbActiveModal);
    });

    describe('confirmDelete', () => {
      it('Should call delete service on confirmDelete', inject(
        [],
        fakeAsync(() => {
          // GIVEN
          jest.spyOn(service, 'delete').mockReturnValue(of(new HttpResponse({})));

          // WHEN
          comp.confirmDelete(123);
          tick();

          // THEN
          expect(service.delete).toHaveBeenCalledWith(123);
          expect(mockActiveModal.close).toHaveBeenCalledWith('deleted');
        })
      ));

      it('Should not call delete service on clear', () => {
        // GIVEN
        jest.spyOn(service, 'delete');

        // WHEN
        comp.cancel();

        // THEN
        expect(service.delete).not.toHaveBeenCalled();
        expect(mockActiveModal.close).not.toHaveBeenCalled();
        expect(mockActiveModal.dismiss).toHaveBeenCalled();
      });
    });
  });
});
