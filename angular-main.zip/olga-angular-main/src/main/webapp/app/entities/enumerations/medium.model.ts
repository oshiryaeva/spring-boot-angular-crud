export enum Medium {
  CD = 'CD',

  DVD = 'DVD',

  MC = 'MC',

  LP = 'LP',

  BOOK = 'BOOK',

  MERCH = 'MERCH',
}
